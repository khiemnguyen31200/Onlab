insert into employer (name, email, website) values ('CMC', 'info@cmc.com.vn', 'https://cmc.com.vn');
insert into employer (name, email, website) values ('FPT', 'hr@fpt.com.vn', 'https://fpt.com');