package vn.techmaster.shopingcart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class ShopingcartApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShopingcartApplication.class, args);
	}

}
