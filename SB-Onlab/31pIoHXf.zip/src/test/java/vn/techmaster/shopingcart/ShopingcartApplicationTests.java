package vn.techmaster.shopingcart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopingcartApplicationTests {

	@Test
	void contextLoads() {
	}

}
